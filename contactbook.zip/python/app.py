from flask import Flask, render_template, request, redirect, url_for, flash
import json
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

class ContactBook:
    def __init__(self, filename="contacts.json"):
        self.filename = filename
        self.contacts = self.load_contacts()

    def load_contacts(self):
        if os.path.exists(self.filename):
            with open(self.filename, "r") as file:
                try:
                    return json.load(file)
                except json.JSONDecodeError:
                    return {}
        return {}

    def save_contacts(self):
        with open(self.filename, "w") as file:
            json.dump(self.contacts, file, indent=4)

    def add_contact(self, name, phone, email):
        if name in self.contacts:
            return False
        self.contacts[name] = {"phone": phone, "email": email}
        self.save_contacts()
        return True

    def get_contacts(self):
        return self.contacts

    def search_contact(self, name):
        return self.contacts.get(name)

    def update_contact(self, name, phone=None, email=None):
        if name in self.contacts:
            if phone:
                self.contacts[name]["phone"] = phone
            if email:
                self.contacts[name]["email"] = email
            self.save_contacts()
            return True
        return False

    def delete_contact(self, name):
        if name in self.contacts:
            del self.contacts[name]
            self.save_contacts()
            return True
        return False

# Initialize the contact book
contact_book = ContactBook()

@app.route('/')
def index():
    contacts = contact_book.get_contacts()
    return render_template('index.html', contacts=contacts)

@app.route('/add', methods=['GET', 'POST'])
def add_contact():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        email = request.form['email']
        if contact_book.add_contact(name, phone, email):
            flash('Contact added successfully!', 'success')
        else:
            flash('Contact already exists!', 'danger')
        return redirect(url_for('index'))
    return render_template('add_contact.html')

@app.route('/update/<name>', methods=['GET', 'POST'])
def update_contact(name):
    contact = contact_book.search_contact(name)
    if not contact:
        flash('Contact not found!', 'danger')
        return redirect(url_for('index'))
    if request.method == 'POST':
        phone = request.form['phone']
        email = request.form['email']
        contact_book.update_contact(name, phone, email)
        flash('Contact updated successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('update_contact.html', name=name, contact=contact)

@app.route('/delete/<name>')
def delete_contact(name):
    if contact_book.delete_contact(name):
        flash('Contact deleted successfully!', 'success')
    else:
        flash('Contact not found!', 'danger')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
